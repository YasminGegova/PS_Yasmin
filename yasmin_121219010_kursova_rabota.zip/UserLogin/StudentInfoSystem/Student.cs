﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Text;

namespace StudentInfoSystem
{
    public class Student
    {
        public Student()
        {
        }

        public Student(String name, String surname, String familyname, String speciality, String faculty, int course)
        {
            this.firstName = name;
            this.secondName = surname;
            this.lastName = familyname;
            this.speciality = speciality;
            this.faculty = faculty;
            this.course = course;
        }
        public int StudentId { get; set; }
        public String firstName { get; set; }
        public String secondName { get; set; }
        public String lastName { get; set; }
        public String speciality { get; set; }
        public String faculty { get; set; }
        public int course { get; set; }
        public String facultyNumber { get; set; }
        public int group { get; set; }
        public String degree { get; set; }
        public String status { get; set; }
        public int stream { get; set; }
        public byte[] Photo { get; set; }

        public override string ToString() { return this.firstName; }

        public static implicit operator DbSet<object>(Student v)
        {
            throw new NotImplementedException();
        }
    }
}

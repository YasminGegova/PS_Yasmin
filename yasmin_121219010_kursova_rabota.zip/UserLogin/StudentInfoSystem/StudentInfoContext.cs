﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Text;
using UserLogin;

namespace StudentInfoSystem
{
    public class StudentInfoContext : DbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<Student> Students { get; set; }


        public StudentInfoContext()
            : base(Properties.Settings.Default.DbConnect)
        {

        }
    }
}

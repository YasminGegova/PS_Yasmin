﻿using System;
using System.Collections.Generic;
using System.Text;
using UserLogin;

namespace StudentInfoSystem
{
    class StudentValidation
    {
        public Student GetStudentDataByUser(User user)
        {
            if (user.fNumber == null)
            {
                return null;
            }

            return new Student();
        }
    }
}

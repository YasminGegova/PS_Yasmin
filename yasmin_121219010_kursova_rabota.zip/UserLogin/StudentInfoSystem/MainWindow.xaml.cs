﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace StudentInfoSystem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    ///
    public partial class MainWindow : Window
    {
        public List<string> StudStatusChoices { get; set; } = new List<string>();
        public MainWindow()
        {
            InitializeComponent();
            FillStudStatusChoices();


            if (TestStudentsIfEmpty())
            {
                CopyTestStudents();
            }
        }

        public bool TestStudentsIfEmpty()
        {
            StudentInfoContext context = new StudentInfoContext();

            IEnumerable<Student> queryStudents = context.Students;

            int countStudents = queryStudents.Count();

            if(queryStudents == null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void CopyTestStudents()
        {
            StudentInfoContext context = new StudentInfoContext();

            StudentData data = new StudentData();
            foreach (Student st in data.TestStudents)
            {
                context.Students.Add(st);
            }

            context.SaveChanges();
        }
        private void FillStudStatusChoices()
        {
            using (IDbConnection connection = new SqlConnection(Properties.Settings.Default.DbConnect))
            {
                string sqlquery = @"SELECT StatusDescr FROM StudStatus";
                IDbCommand command = new SqlCommand();
                command.Connection = connection;
                connection.Open();
                command.CommandText = sqlquery;
                IDataReader reader = command.ExecuteReader();
                bool notEndOfResult;
                notEndOfResult = reader.Read();

                while (notEndOfResult)
                {
                    string s = reader.GetString(0);
                    StudStatusChoices?.Add(s);
                    notEndOfResult = reader.Read();
                }
            }
        }

        private void ClearForms()
        {
            foreach (var item in StudentData.Children)
            {
                if (item is TextBox)
                {
                    ((TextBox)item).Text = string.Empty;
                }
            }
        }

        private void DeactivateControls()
        {
            foreach (var item in StudentData.Children)
            {
                if (item is TextBox)
                {
                    ((TextBox)item).IsEnabled = false;
                }
            }
        }

        private void ActivateControls()
        {
            foreach (var item in StudentData.Children)
            {
                if (item is TextBox)
                {
                    ((TextBox)item).IsEnabled = true;
                }
            }
        }

        private void EnterUser()
        {
            StudentData studentData = new StudentData();
            Student student = new Student();

            foreach (var item in StudentData.Children)
            {
                if (item is TextBox)
                {
                    if (((TextBox)item).Name.Equals("txtFirstName"))
                    {
                        student.firstName = ((TextBox)item).Text;
                    }
                    else if (((TextBox)item).Name.Equals("txtMiddleName"))
                    {
                        student.secondName = ((TextBox)item).Text;
                    }
                    else if (((TextBox)item).Name.Equals("txtLastName"))
                    {
                        student.lastName = ((TextBox)item).Text;
                    }
                    else if (((TextBox)item).Name.Equals("txtFaculty"))
                    {
                        student.faculty = ((TextBox)item).Text;
                    }
                    else if (((TextBox)item).Name.Equals("txtSpeciality"))
                    {
                        student.speciality = ((TextBox)item).Text;
                    }
                    else if (((TextBox)item).Name.Equals("txtDegree"))
                    {
                        student.degree = ((TextBox)item).Text;
                    }
                    else if (((TextBox)item).Name.Equals("txtFacultyNumber"))
                    {
                        student.facultyNumber = ((TextBox)item).Text;
                    }
                    else if (((TextBox)item).Name.Equals("txtStatus"))
                    {
                        student.status = ((TextBox)item).Text;
                    }
                    else if (((TextBox)item).Name.Equals("txtCourse"))
                    {
                        student.course = int.Parse(((TextBox)item).Text);
                    }
                    else if (((TextBox)item).Name.Equals("txtStream"))
                    {
                        student.stream = int.Parse(((TextBox)item).Text);
                    }
                    else if (((TextBox)item).Name.Equals("txtGroup"))
                    {
                        student.group = int.Parse(((TextBox)item).Text);
                    }
                }
            }
        }

    }
}

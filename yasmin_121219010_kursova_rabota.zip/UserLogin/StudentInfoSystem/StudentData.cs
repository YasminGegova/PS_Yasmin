﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StudentInfoSystem
{
    class StudentData
    {
        public List<Student> TestStudents { get; private set; }

        public StudentData()
        {
            TestStudents = new List<Student>();

            TestStudents?.Add(new Student()
            {
                firstName = "Yasmin",
                secondName = "Yuseinova",
                lastName = "Gegova",
                speciality = "Computer and software engineering",
                faculty = "FCST",
                course = 3,
                facultyNumber = "121219010",
                group = 30,
                degree = "None",
                status = "studying",
                stream = 9
            });
        }
    }
}

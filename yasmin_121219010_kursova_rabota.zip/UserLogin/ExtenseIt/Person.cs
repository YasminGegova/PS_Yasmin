﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExtenseIt
{
    public class Person
    {
        public String Name { get; set; }
        public String Department { get; set; }
        public List<Expense> Expenses { get; set; }
    }
}

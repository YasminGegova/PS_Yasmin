﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExtenseIt
{
    public class Expense
    {
        public String ExpenseType { get; set; }
        public double ExpenseAmount { get; set; }
    }
}

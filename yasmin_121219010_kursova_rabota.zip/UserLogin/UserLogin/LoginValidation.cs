﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UserLogin
{
    public class LoginValidation
    {
        static public int currentUserRole { get; private set; }
        private String userName;
        private String userPass;
        private String errorMessage;
        private ActionOnError actionErr;

        public delegate void ActionOnError(string errorMsg);
        public LoginValidation(string name, string pass, ActionOnError errorAct)
        {
            this.userName = name;
            this.userPass = pass;
            this.actionErr = errorAct;
        }

        
        public Boolean ValidateUserInput(ref User user)
        {
            Boolean emptyUserName;
            emptyUserName = userName.Equals(String.Empty);

            if(emptyUserName == true)
            {
                errorMessage = "Name is missing";
                actionErr(errorMessage);
                currentUserRole = (int)UserRoles.ANONYMOUS;
                return false;
            }

            Boolean emptyPassword;
            emptyPassword = userPass.Equals(String.Empty);

            if (emptyPassword == true)
            {
                errorMessage = "Password is missing";
                actionErr(errorMessage);
                currentUserRole = (int)UserRoles.ANONYMOUS;
                return false;

            }

            if(userName.Length < 5)
            {
                errorMessage = "Name is too short";
                actionErr(errorMessage);
                currentUserRole = (int)UserRoles.ANONYMOUS;
                return false;
            }

            if (userPass.Length < 5)
            {
                errorMessage = "Password is too short";
                actionErr(errorMessage);
                currentUserRole = (int)UserRoles.ANONYMOUS;
                return false;
            }

            user = UserData.IsUserPassCorrect(userName, userPass);

            if(user == null)
            {
                errorMessage = "Wrong name or password";
                actionErr(errorMessage);
                currentUserRole = (int)UserRoles.ANONYMOUS;
                return false;
            }

            currentUserRole = (int)(UserRoles)user.role;
            Logger.LogActivity("Successful Login");
            return true;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Text;

namespace UserLogin
{
    class UserContext : DbContext
    {
        public DbSet<User> Users { get; set; }

        public DbSet<Log> Logs { get; set; }

        public UserContext()
            : base("Data Source=DESKTOP-N3VB242;Initial Catalog=ConsoleApp;Integrated Security=True")
        {

        }
    }
}

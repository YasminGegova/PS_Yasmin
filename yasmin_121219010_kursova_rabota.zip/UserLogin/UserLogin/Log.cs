﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UserLogin
{
    class Log
    {
        public int LogId { get; set; }

        public string Message { get; set; }
    }
}

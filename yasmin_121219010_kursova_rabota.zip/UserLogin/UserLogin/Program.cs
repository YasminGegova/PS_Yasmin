﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace UserLogin
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter user name: ");
            String userName = Console.ReadLine();

            Console.WriteLine("Enter password: ");
            String userPass = Console.ReadLine();

            LoginValidation loginValid = new LoginValidation(userName, userPass, actionOnError);

            User? user = null;

            if(loginValid.ValidateUserInput(ref user))
            {
                Console.WriteLine(user.name);
                Console.WriteLine(user.password);
                Console.WriteLine(user.fNumber);
                Console.WriteLine((UserRoles)user.role);

                switch (LoginValidation.currentUserRole)
                {
                    case 1:
                        Console.WriteLine("Admin");

                        showMenu();

                        int choice = int.Parse(Console.ReadLine());

                        switch(choice)
                        {
                            case 1:
                                Console.WriteLine("Enter username: ");
                                String userForRole = Console.ReadLine();

                                Console.WriteLine("Enter new role: ");
                                UserRoles newRole = (UserRoles)int.Parse(Console.ReadLine());

                                UserData.AssignUserRole(userForRole, newRole);
                                break;
                            case 2:
                                Console.WriteLine("Enter username: ");
                                String userForExpireDate = Console.ReadLine();

                                Console.WriteLine("Enter new expire date: ");
                                DateTime newExpireDate;
                                DateTime.TryParse(Console.ReadLine(), out newExpireDate);

                                UserData.SetUserActiveTo(userForExpireDate, newExpireDate);
                                break;
                            case 3:
                                break;
                            case 4:
                                StringBuilder log = new StringBuilder();
                                IEnumerable<string> allActs = Logger.GetAllActivities();

                                foreach (string act in allActs)
                                {
                                    log.AppendLine(act);
                                }

                                Console.WriteLine(log.ToString());
                                break;
                            case 5:
                                StringBuilder result = new StringBuilder();
                                Console.WriteLine("Enter filter: ");
                                String filter = Console.ReadLine();
                                IEnumerable<String> currentActs = Logger.GetCurrentSessionActivities(filter);

                                foreach (string currentActivity in currentActs)
                                {
                                    result.AppendLine(currentActivity);
                                }
                                Console.WriteLine(result.ToString());
                                break;
                            default:
                                break;
                        }

                        break;
                    case 2:
                        Console.WriteLine("Inspector");
                        break;
                    case 3:
                        Console.WriteLine("Professor");
                        break;
                    case 4:
                        Console.WriteLine("Student");
                        break;
                    default:
                        Console.WriteLine("Anonymous");
                        break;
                }
                Console.WriteLine(LoginValidation.currentUserRole);
            }
            
        }

        static public void actionOnError(string errMsg)
        {
            Console.WriteLine("!!! " + errMsg + " !!!");
        }

        static public void showMenu()
        {
            Console.WriteLine("Choose option:");
            Console.WriteLine("1: Change user role");
            Console.WriteLine("2: Change user expire date");
            Console.WriteLine("3: List of users");
            Console.WriteLine("4: View log of activity");
            Console.WriteLine("5: View current activity");
        }
    }
}

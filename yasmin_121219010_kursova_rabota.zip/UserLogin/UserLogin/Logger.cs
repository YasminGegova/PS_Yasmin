﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace UserLogin
{
    static public class Logger
    {
        static private List<string> currentSessionActivities = new List<string>();

        static public void LogActivity(String activity)
        {
            String activityLine = DateTime.Now + ";"
            + LoginValidation.currentUserRole + ";"
            + activity;

            currentSessionActivities.Add(activityLine);

            if(File.Exists("log.txt"))
            {
                File.WriteAllText(("log.txt"), activityLine);
            }
        }

        static public IEnumerable<String> GetCurrentSessionActivities(String filter)
        {
            List<String> filteredActivities =(from activity in currentSessionActivities
                                              where activity.Contains(filter)
                                              select activity).ToList();
            return filteredActivities;
        }

        public static IEnumerable<string> GetAllActivities()
        {
            return File.ReadAllLines("log.txt");
        }
    }
}

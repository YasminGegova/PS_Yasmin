﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UserLogin
{
    public class User
    {
        public System.Int32 UserId { get; set; }
        public String name { get; set; }
        public String password { get; set; }
        public String fNumber { get; set; }
        public Int32 role { get; set; }
        public DateTime created { get; set; }

        public DateTime? expireDate { get; set; }
    }
}

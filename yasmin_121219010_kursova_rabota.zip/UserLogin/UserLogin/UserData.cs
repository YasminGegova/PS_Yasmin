﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UserLogin
{
    static public class UserData
    {
        static private List<User> _testUsers;
        static public List<User> TestUsers
        {
            get {
                ResetTestUserData();
                return _testUsers;
            }
            set { }
        }

        static public User IsUserPassCorrect(String username, String pass)
        {

            UserContext context = new UserContext();

            return context.Users.FirstOrDefault(u => u.name == username && u.password == pass);

        }

        static public void AssignUserRole(String username, UserRoles userRole)
        {
            UserContext context = new UserContext();

            User? user = context.Users.FirstOrDefault(u => u.name == username);

            if (user != null)
            {
                user.role = (int)userRole;
            }

            context.SaveChanges();
        }

        static public void SetUserActiveTo(String username, DateTime accountExpireDate)
        {
            foreach(User user in TestUsers)
            {
                if(user.name.Equals(username))
                {
                    user.expireDate = accountExpireDate;
                }
            }

            Logger.LogActivity("Expire date is changed for " + username);
        }

        static private void ResetTestUserData()
        {
            if (_testUsers == null)
            {
                _testUsers = new List<User>();

                for(int idx = 0; idx < 3; idx++)
                {
                    if (idx == 0)
                    {
                        _testUsers.Add(new User()
                        {
                            name = "Yasmin",
                            password = "Asd123",
                            fNumber = "121219010",
                            role = 1,
                            created = DateTime.Now,
                            expireDate = DateTime.MaxValue
                        });
                    }

                    if(idx == 1)
                    {
                        _testUsers.Add(new User()
                        {
                            name = "user2",
                            password = "Asd1234",
                            fNumber = "121219011",
                            role = 4,
                            created = DateTime.Now,
                            expireDate = DateTime.MaxValue
                        });
                    }

                    if(idx == 2)
                    {
                        _testUsers.Add(new User()
                        {
                            name = "user3",
                            password = "Asd12345",
                            fNumber = "121219012",
                            role = 4,
                            created = DateTime.Now,
                            expireDate = DateTime.MaxValue
                        });
                    }
                }
            }
            
        }

    }
}

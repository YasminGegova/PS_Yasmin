﻿namespace UserLogin
{
    public enum UserRoles
    {
        ANONYMOUS = 0,
        ADMIN,
        INSPECTOR,
        PROFESSOR,
        STUDENT
    }
}